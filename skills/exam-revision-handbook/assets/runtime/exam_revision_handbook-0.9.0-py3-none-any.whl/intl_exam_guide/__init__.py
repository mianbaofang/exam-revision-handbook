"""GCSE, IGCSE, A-Level, and AP revision handbook generator."""

__all__ = ["__version__"]
__version__ = "0.9.0"
