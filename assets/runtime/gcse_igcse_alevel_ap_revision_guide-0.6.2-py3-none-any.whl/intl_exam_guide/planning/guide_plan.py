from __future__ import annotations

from dataclasses import replace
import os

from intl_exam_guide.models import (
    GuidePlan,
    GuideRunOptions,
    PracticeItem,
    Qualification,
    Topic,
    TopicGuide,
    VisualBrief,
)
from intl_exam_guide.planning.anti_ai_language import polish_ai_language, polish_texts
from intl_exam_guide.planning.checklists import build_checklist
from intl_exam_guide.planning.explanation_styles import (
    styled_explanation,
    styled_explanation_en,
)
from intl_exam_guide.planning.localization import (
    is_generic_zh_label,
    zh_point_label,
    zh_point_labels,
    zh_topic_reference,
    zh_visual_trigger,
    zh_visual_type,
)
from intl_exam_guide.planning.practice_generator import (
    build_practice_item,
    choose_command_word,
    choose_difficulty,
    concrete_example,
    concrete_example_zh,
)
from intl_exam_guide.planning.language_policy import LANGUAGE_CHOICES, handbook_body_language
from intl_exam_guide.planning.source_points import normalized_student_topic, visible_source_points
from intl_exam_guide.planning.visual_routing import (
    build_visual_brief,
    choose_provider_for_visual,
    choose_visual_type,
)


STYLE_LABELS = {
    "formal": "formal exam-focused",
    "friendly": "friendly",
    "life": "real-life context",
    "story": "story-driven",
    "detective": "detective reasoning",
    "adventure": "original adventure mode",
}

IMAGE_PROVIDERS = {
    "prompt-queue",
    "custom",
}
RECOMMENDED_IMAGE_MODEL_LABELS = {
    "gpt-image-2",
    "qwen-image-pro",
    "sensenova-u1-fast",
}

__all__ = [
    "STYLE_LABELS",
    "IMAGE_PROVIDERS",
    "RECOMMENDED_IMAGE_MODEL_LABELS",
    "LANGUAGE_CHOICES",
    "build_guide_plan",
    "build_run_options",
    "normalize_image_provider",
    "build_topic_guide",
    "build_checklist",
    "build_revision_stages",
    "zh_point_label",
    "zh_point_labels",
    "zh_topic_reference",
    "zh_visual_trigger",
    "zh_visual_type",
    "build_practice_item",
    "choose_command_word",
    "choose_difficulty",
    "concrete_example",
    "concrete_example_zh",
    "build_visual_brief",
    "choose_provider_for_visual",
    "choose_visual_type",
    "styled_explanation",
    "styled_explanation_en",
]


def build_guide_plan(
    qualification: Qualification,
    questions_per_topic: int = 1,
    image_provider: str | None = None,
    explanation_style: str = "friendly",
    output_language: str = "en",
    requested_subject: str | None = None,
    exam_year: str | None = None,
    image_model: str | None = None,
    image_endpoint_url: str | None = None,
    image_api_key_env: str | None = None,
) -> GuidePlan:
    run_options = build_run_options(
        qualification=qualification,
        requested_subject=requested_subject,
        image_provider=image_provider,
        explanation_style=explanation_style,
        output_language=output_language,
        exam_year=exam_year,
        image_model=image_model,
        image_endpoint_url=image_endpoint_url,
        image_api_key_env=image_api_key_env,
    )
    body_language = handbook_body_language(run_options.output_language)
    body_options = replace(run_options, output_language=body_language)
    topic_guides: list[TopicGuide] = []
    practice_items: list[PracticeItem] = []
    visual_briefs: list[VisualBrief] = []
    diagram_briefs: list[str] = []

    prepared_topics = [
        topic if is_scope_exclusion_topic(topic) else normalized_student_topic(topic)
        for topic in qualification.topics
    ]
    qualification = replace(qualification, topics=prepared_topics)
    handbook_topics = [
        topic for topic in qualification.topics if not is_scope_exclusion_topic(topic)
    ]

    for topic_index, topic in enumerate(handbook_topics):
        points = visible_source_points(topic, limit=4)
        guide = build_topic_guide(
            topic,
            qualification.qualification_type,
            body_options.explanation_style,
            body_options.output_language,
        )
        topic_guides.append(guide)
        visual = build_visual_brief(topic, guide, body_options, qualification.subject_area)
        if visual:
            visual_briefs.append(visual)
        diagram_briefs.append(guide.diagram_brief)
        for number in range(questions_per_topic):
            variant_number = topic_index * max(1, questions_per_topic) + number
            practice_items.append(
                build_practice_item(
                    topic,
                    points,
                    number,
                    qualification.qualification_type,
                    run_options.explanation_style,
                    body_options.output_language,
                    qualification.subject_area,
                    variant_number=variant_number,
                )
            )

    revision_stages = build_revision_stages(
        qualification.qualification_type,
        body_options.output_language,
    )
    return GuidePlan(
        qualification=qualification,
        run_options=run_options,
        topic_guides=topic_guides,
        practice_items=practice_items,
        visual_briefs=visual_briefs,
        diagram_briefs=diagram_briefs,
        revision_stages=revision_stages,
    )


def is_scope_exclusion_topic(topic: Topic) -> bool:
    """Return True when a source point is only an exam-scope exclusion note."""

    primary = topic.points[0] if topic.points else ""
    title_focus = topic.title.rsplit(":", 1)[-1]
    text = f"{title_focus} {primary}".lower()
    exclusion_phrases = [
        "will not be set",
        "will not be assessed",
        "will not be tested",
        "is not required",
        "are not required",
        "not required",
        "not be required",
        "not be tested",
        "not expected",
        "outside the scope",
    ]
    if not any(phrase in text for phrase in exclusion_phrases):
        return False
    learning_terms = [
        "restricted to",
        "include",
        "includes",
        "including",
        "to include",
        "use of",
        "application of",
        "applications of",
    ]
    return not any(term in text for term in learning_terms)


def build_run_options(
    qualification: Qualification,
    requested_subject: str | None,
    image_provider: str | None,
    explanation_style: str,
    output_language: str,
    exam_year: str | None,
    image_model: str | None,
    image_endpoint_url: str | None,
    image_api_key_env: str | None,
) -> GuideRunOptions:
    provider = normalize_image_provider(
        image_provider, image_model, image_endpoint_url, image_api_key_env
    )
    style = explanation_style if explanation_style in STYLE_LABELS else "friendly"
    language = output_language if output_language in LANGUAGE_CHOICES else "en"
    return GuideRunOptions(
        requested_subject=requested_subject or qualification.title,
        image_provider=provider,
        explanation_style=style,
        output_language=language,
        exam_year=exam_year or qualification.selected_exam_year,
        image_model=image_model,
        image_endpoint_url=image_endpoint_url,
        image_api_key_env=image_api_key_env,
    )


def normalize_image_provider(
    image_provider: str | None,
    image_model: str | None,
    image_endpoint_url: str | None,
    image_api_key_env: str | None,
) -> str:
    provider = (image_provider or "prompt-queue").strip()
    if provider in RECOMMENDED_IMAGE_MODEL_LABELS:
        # Recommended model names are not proof of a callable provider. Keep the
        # base handbook honest and queue complex visuals for external generation.
        return "prompt-queue"
    if provider == "custom":
        if (
            image_model
            and image_endpoint_url
            and image_api_key_env
            and os.environ.get(image_api_key_env)
        ):
            return "custom"
        return "prompt-queue"
    if provider in IMAGE_PROVIDERS:
        return provider
    return "prompt-queue"


def build_topic_guide(
    topic: Topic,
    qualification_type: str,
    explanation_style: str,
    output_language: str,
) -> TopicGuide:
    points = visible_source_points(topic, limit=5)
    if output_language == "en":
        visible_points = points
    else:
        labels = zh_point_labels(points)
        visible_points = [label for label in labels if not is_generic_zh_label(label)]
        if not visible_points:
            fallback = zh_point_label(topic.title, 0)
            visible_points = [
                fallback if not is_generic_zh_label(fallback) else zh_topic_reference(topic)
            ]
    primary = visible_points[0]
    if output_language == "en":
        if qualification_type in {"international_as_a_level", "uk_as_a_level"}:
            level_hint = "A-Level unit"
        elif qualification_type == "advanced_placement":
            level_hint = "AP course topic"
        else:
            level_hint = "GCSE topic"
    else:
        level_hint = (
            "A-Level 单元"
            if qualification_type in {"international_as_a_level", "uk_as_a_level"}
            else "GCSE 知识点"
        )
    essence, analogy, mini_worked_example, pitfall = styled_explanation(
        topic=topic,
        primary=primary,
        level_hint=level_hint,
        explanation_style=explanation_style,
        output_language=output_language,
    )
    essence, analogy, mini_worked_example, pitfall = polish_texts(
        [essence, analogy, mini_worked_example, pitfall],
        output_language,
    )
    worked_solution_steps = (
        [
            "Read the command word and circle the data or conditions in the question.",
            f"Match the question to this syllabus point: {points[0]}.",
            "Write the formula, definition, diagram relationship, or judgement rule you need.",
            "Check the unit, precision, symbols, and final sentence against the question.",
        ]
        if output_language == "en"
        else [
            "读题：圈出指令词和题目给出的数据/条件。",
            f"定位：把题目匹配到{primary}。",
            "作答：写出公式、定义、图形关系或判断过程。",
            "检查：单位、精度、符号和最终句子是否回答了题问。",
        ]
    )
    checklist = build_checklist(
        visible_points,
        output_language,
        source_text=" ".join([topic.title, *points]),
        topic_title=topic.title,
    )
    diagram_brief = (
        (
            f"Draw a clean concept map for '{topic.title}' with the central title in the middle, "
            f"branches for {', '.join(visible_points[:4])}, and one short exam-action label on each branch."
        )
        if output_language == "en"
        else (
            f"为“{zh_topic_reference(topic)}”绘制清晰概念图：中心放主题，分支覆盖 "
            f"{'、'.join(visible_points[:4])}，每个分支加一个简短做题动作标签。"
        )
    )
    return TopicGuide(
        topic_title=topic.title,
        essence=essence,
        analogy=analogy,
        mini_worked_example=mini_worked_example,
        worked_solution_steps=polish_texts(worked_solution_steps, output_language),
        pitfall=pitfall,
        checklist=polish_texts(checklist, output_language),
        diagram_brief=polish_ai_language(diagram_brief, output_language),
        source_snippets=topic.source_snippets[:3],
        source_points=points,
    )


def build_revision_stages(qualification_type: str, output_language: str = "en") -> list[str]:
    if output_language == "zh-CN":
        if qualification_type in {"international_as_a_level", "uk_as_a_level"}:
            return [
                "第 1 阶段 - 单元地图：先分清 AS、A2 或模块单元，再做综合题。",
                "第 2 阶段 - 建构：把每个单元点整理成短讲解、一道应用题和一个易错点。",
                "第 3 阶段 - 测试：先按单元练，再把不同单元放在一起做综合练习。",
            ]
        return [
            "第 1 阶段 - 线性地图：先看完整门课的主题结构，再进入混合题。",
            "第 2 阶段 - 建构：把每个大纲点整理成一页笔记、一道例题和一个易错点。",
            "第 3 阶段 - 测试：练习整卷混合题，复盘错题，并每周更新检查清单。",
        ]
    if qualification_type in {"international_as_a_level", "uk_as_a_level"}:
        return [
            "Stage 1 - Unit map: separate AS and A2 or modular units before mixing questions.",
            "Stage 2 - Build: turn each unit point into a short explanation, one application prompt, and one pitfall.",
            "Stage 3 - Test: practise by unit first, then combine units in mixed questions.",
        ]
    if qualification_type == "advanced_placement":
        return [
            "Stage 1 - Course framework: map the official AP units, skills, and weighting before mixing questions.",
            "Stage 2 - Build: connect each course topic to the AP skills and evidence required by the exam.",
            "Stage 3 - Test: practise the relevant AP question formats, review errors, and revisit weak units.",
        ]
    return [
        "Stage 1 - Linear map: learn the full-course topic structure before doing mixed papers.",
        "Stage 2 - Build: turn each syllabus point into a one-page note, one worked example, and one pitfall.",
        "Stage 3 - Test: practise mixed end-of-course questions, review errors, and update the checklist weekly.",
    ]
