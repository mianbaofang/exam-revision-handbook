from __future__ import annotations

import re
import urllib.error
from pathlib import Path

from intl_exam_guide.models import Qualification, SourceRecord
from intl_exam_guide.providers.base import ExamBoardProvider, Link
from intl_exam_guide.providers.common import (
    BasicPageParser,
    attach_pdf_content,
    clean_text,
    code_from_text,
    dedupe_links,
    find_pdf_link,
    format_candidate_choices,
    first_assessment_from_nodes,
    first_node_text,
    first_teaching_from_nodes,
    infer_qualification_type,
    is_pdf_url,
    is_url,
    normalize_level,
    parse_page,
    qualification_family,
    subject_terms_from_query,
    subject_slug_from_query,
    title_from_url,
)


class PearsonEdexcelProvider(ExamBoardProvider):
    name = "pearson"
    supported_levels = ("international_gcse", "international_as_a_level")
    course_market = "international"

    def find_qualification(
        self, query: str, level: str | None = None, exam_year: str | None = None
    ) -> Link:
        if not is_url(query):
            return self._find_candidate_by_subject(query, level)
        qtype = self._qualification_type(query, query, level)
        return Link(text=title_from_url(query), href=query, qualification_type=qtype)

    def parse_qualification(
        self, page_url: str, level: str | None = None, exam_year: str | None = None
    ) -> Qualification:
        if is_pdf_url(page_url):
            title = title_from_url(page_url)
            qtype = self._qualification_type(title, page_url, level)
            return self._qualification_from_parts(
                title=title,
                page_url=page_url,
                specification_url=page_url,
                qtype=qtype,
                first_teaching=None,
                first_assessment=None,
            )

        parser = parse_page(page_url)
        title = clean_text(
            first_node_text(parser, "h1") or parser.title or title_from_url(page_url)
        )
        qtype = self._qualification_type(title, page_url, level)
        specification_url = pearson_specification_url(parser, level)
        if specification_url and not pearson_is_specification_pdf(specification_url):
            specification_url = None
        if not specification_url:
            raise ValueError(
                "No Pearson specification PDF link found on the supplied page. "
                "Use a direct Pearson specification PDF URL or another official subject-page URL."
            )
        return self._qualification_from_parts(
            title=title,
            page_url=page_url,
            specification_url=specification_url,
            qtype=qtype,
            first_teaching=first_teaching_from_nodes(parser.nodes),
            first_assessment=first_assessment_from_nodes(parser.nodes),
        )

    def download_specification(
        self,
        qualification: Qualification,
        output_dir: Path,
        exam_year: str | None = None,
    ) -> Qualification:
        if not qualification.source.specification_url:
            raise ValueError("No Pearson specification PDF URL is attached to the qualification.")
        return attach_pdf_content(
            qualification,
            output_dir,
            qualification.source.specification_url,
            self.name,
            exam_year=exam_year,
        )

    def _find_candidate_by_subject(self, query: str, level: str | None) -> Link:
        candidates = []
        for url in self.candidate_urls(query, level):
            link = self._validate_candidate_url(url, level)
            if link:
                candidates.append(link)
        candidates = dedupe_links(candidates)
        if len(candidates) == 1:
            return candidates[0]
        if len(candidates) > 1:
            raise ValueError(format_candidate_choices("Pearson Edexcel", query, candidates))
        raise ValueError(
            "Pearson Edexcel could not confirm one official subject page from the subject name alone. "
            "Provide the official Pearson subject-page URL or direct specification PDF URL."
        )

    def _validate_candidate_url(self, url: str, level: str | None) -> Link | None:
        try:
            parser = parse_page(url)
        except (OSError, TimeoutError, urllib.error.URLError, UnicodeDecodeError):
            return None
        title = clean_text(first_node_text(parser, "h1") or parser.title or title_from_url(url))
        lower_title = title.lower()
        if "page not found" in lower_title or "404" in lower_title:
            return None
        qtype = self._qualification_type(title, url, level)
        return Link(text=title, href=url, qualification_type=qtype)

    def candidate_urls(self, query: str, level: str | None) -> list[str]:
        return pearson_candidate_urls(query, level)

    def _qualification_type(self, title: str, url: str, level: str | None) -> str:
        if self.course_market == "uk-domestic":
            return uk_qualification_type(title, url, level)
        return infer_qualification_type(title, url, level)

    def _qualification_from_parts(
        self,
        title: str,
        page_url: str,
        specification_url: str,
        qtype: str,
        first_teaching: str | None,
        first_assessment: str | None,
    ) -> Qualification:
        title = pearson_clean_title(title)
        code = pearson_code_from_title_or_url(title, page_url)
        subject_area = pearson_subject_area(title, page_url)
        family = pearson_qualification_family(self.course_market, qtype)
        source = SourceRecord(
            provider=self.name,
            page_url=page_url,
            course_market=self.course_market,
            specification_url=specification_url,
            qualification_family=family,
            first_teaching=first_teaching,
            first_assessment=first_assessment,
        )
        return Qualification(
            title=title,
            code=code,
            qualification_type=qtype,
            subject_area=subject_area,
            page_url=page_url,
            summary=pearson_summary_for_market(
                self.course_market, qtype, first_teaching, first_assessment
            ),
            topics=[],
            assessments=[],
            source=source,
            audience_note=pearson_audience_note_for_market(self.course_market, qtype),
            provider=self.name,
            qualification_family=family,
            route_tags=pearson_route_tags_for_market(self.course_market, qtype, page_url),
        )


class PearsonEdexcelUKProvider(PearsonEdexcelProvider):
    """Official Pearson Edexcel GCSE and A-Level source route for UK centres."""

    name = "pearson_uk"
    supported_levels = ("uk_gcse", "uk_as_a_level")
    course_market = "uk-domestic"

    def candidate_urls(self, query: str, level: str | None) -> list[str]:
        return pearson_uk_candidate_urls(query, level)


def pearson_clean_title(title: str) -> str:
    cleaned = re.sub(r"\s*\|\s*Pearson\s+qualifications\s*$", "", title, flags=re.I)
    cleaned = re.sub(r"^Edexcel\s+", "Pearson Edexcel ", cleaned, flags=re.I)
    return clean_text(cleaned)


def pearson_code_from_title_or_url(title: str, url: str) -> str | None:
    pearson_code = re.search(r"\(([0-9][A-Za-z][A-Za-z0-9]{2}|[A-Za-z][0-9][A-Za-z0-9]{2})\)", title)
    if pearson_code:
        return pearson_code.group(1).upper()
    code = code_from_text(title)
    if code and not pearson_is_year_code(code):
        return code
    slug = title_from_url(url).lower()
    matches = re.findall(r"\b(?!20\d{2}\b)([0-9][A-Za-z][A-Za-z0-9]{2}|[A-Za-z][0-9][A-Za-z0-9]{2})\b", slug)
    return matches[0].upper() if matches else None


def pearson_is_year_code(value: str) -> bool:
    return bool(re.fullmatch(r"20\d{2}", value.strip()))


def pearson_subject_area(title: str, url: str) -> str | None:
    cleaned = re.sub(
        r"\b(Pearson|Edexcel|International|GCSE|Advanced|Levels?|A\s*Level|Specification)\b|\(\d{4}\)",
        " ",
        title,
        flags=re.I,
    )
    cleaned = clean_text(cleaned)
    if cleaned:
        return cleaned
    parts = [part for part in re.split(r"[-_/]", url) if part and not part.isdigit()]
    return clean_text(" ".join(parts[-4:])).title() if parts else None


def pearson_is_specification_pdf(url: str) -> bool:
    lower = url.lower()
    if ".pdf" not in lower:
        return False
    if any(
        term in lower for term in ["past-paper", "past paper", "mark-scheme", "welcome", "guide"]
    ):
        return False
    return "specification" in lower or "/spec" in lower


def pearson_summary(
    qtype: str,
    first_teaching: str | None,
    first_assessment: str | None,
) -> list[str]:
    structure = (
        "Pearson Edexcel International A-Level is normally modular and may include unit routes."
        if qtype == "international_as_a_level"
        else "Pearson Edexcel International GCSE may be linear or modular depending on the subject and specification."
    )
    values = [structure]
    if first_teaching:
        values.append(f"First teaching: {first_teaching}")
    if first_assessment:
        values.append(f"First external assessment: {first_assessment}")
    return values


def pearson_audience_note(qtype: str) -> str:
    if qtype == "international_as_a_level":
        return (
            "Pearson Edexcel International A-Level qualifications are international qualifications "
            "for international students outside the UK, commonly structured through AS/A2 or unit routes. "
            "Confirm available units and exam series with the school or exam centre."
        )
    return (
        "Pearson Edexcel International GCSEs are designed for international students "
        "and schools outside the UK. Some subjects offer linear or modular assessment "
        "routes, so families should confirm the chosen route and exam series locally."
    )


def pearson_route_tags(qtype: str, url: str) -> list[str]:
    tags = ["Pearson Edexcel"]
    if qtype == "international_as_a_level":
        tags.append("modular")
    if "modular" in url.lower():
        tags.append("modular")
    if "international-gcse" in url.lower():
        tags.append("international-gcse")
    return list(dict.fromkeys(tags))


def pearson_specification_url(parser: BasicPageParser, level: str | None) -> str | None:
    """Choose the official PDF matching the requested AS or A-Level route."""

    normalized = normalize_level(level)
    candidates: list[tuple[int, str]] = []
    for link in getattr(parser, "links", []):
        combined = f"{link.text} {link.href}".lower()
        if not pearson_is_specification_pdf(link.href):
            continue
        if any(term in combined for term in ("past-paper", "past paper", "mark-scheme", "guide")):
            continue
        score = 10
        if normalized in {"as", "as-level"} and re.search(r"(?:^|[-_/ ])as(?:[-_/ ])", combined):
            score += 20
        if normalized in {"a-level", "alevel", "as-a-level"} and "a-level" in combined:
            score += 20
        candidates.append((score, link.href))
    if not candidates:
        return find_pdf_link(
            parser,
            include_terms=("specification", "download"),
            exclude_terms=("past-paper", "past paper", "mark-scheme", "mark scheme", "guide"),
        )
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def uk_qualification_type(title: str, url: str, level: str | None) -> str:
    combined = f"{title} {url} {level or ''}".lower()
    if normalize_level(level) in {"as", "as-level", "a-level", "alevel", "as-a-level"}:
        return "uk_as_a_level"
    if "as and a level" in combined or "a-level" in combined or "a level" in combined:
        return "uk_as_a_level"
    if "gcse" in combined:
        return "uk_gcse"
    return "unknown"


def pearson_qualification_family(course_market: str, qtype: str) -> str:
    if course_market == "uk-domestic":
        return "Pearson Edexcel AS & A Level" if qtype == "uk_as_a_level" else "Pearson Edexcel GCSE"
    return qualification_family("pearson", qtype)


def pearson_summary_for_market(
    course_market: str,
    qtype: str,
    first_teaching: str | None,
    first_assessment: str | None,
) -> list[str]:
    if course_market != "uk-domestic":
        return pearson_summary(qtype, first_teaching, first_assessment)
    structure = (
        "Pearson Edexcel UK AS and A Level assessment follows the selected UK specification."
        if qtype == "uk_as_a_level"
        else "Pearson Edexcel UK GCSE assessment follows the selected UK specification."
    )
    values = [structure]
    if first_teaching:
        values.append(f"First teaching: {first_teaching}")
    if first_assessment:
        values.append(f"First external assessment: {first_assessment}")
    return values


def pearson_audience_note_for_market(course_market: str, qtype: str) -> str:
    if course_market != "uk-domestic":
        return pearson_audience_note(qtype)
    if qtype == "uk_as_a_level":
        return "Pearson Edexcel AS and A Levels are UK qualifications. Confirm the selected specification and exam series with the school or exam centre."
    return "Pearson Edexcel GCSEs are UK qualifications. Confirm the selected specification, tier, and exam series with the school or exam centre."


def pearson_route_tags_for_market(course_market: str, qtype: str, url: str) -> list[str]:
    if course_market != "uk-domestic":
        return pearson_route_tags(qtype, url)
    tags = ["Pearson Edexcel", "uk-domestic"]
    if qtype == "uk_as_a_level":
        tags.append("A-Level")
    return tags


def pearson_candidate_urls(query: str, level: str | None) -> list[str]:
    slugs = pearson_subject_slugs(query, level)
    if not slugs:
        return []
    normalized = normalize_level(level)
    urls: list[str] = []
    if normalized in {None, "gcse", "igcse", "international-gcse"}:
        base = "https://qualifications.pearson.com/en/qualifications/edexcel-international-gcses"
        for slug in slugs:
            urls.extend(
                [
                    f"{base}/international-gcse-{slug}-2016.html",
                    f"{base}/international-gcse-{slug}-2017.html",
                    f"{base}/{slug}-2023-modular.html",
                    f"{base}/{slug}-2024-modular.html",
                ]
            )
    if normalized in {None, "a-level", "alevel", "as-a-level", "international-as-a-level"}:
        for slug in slugs:
            urls.append(
                "https://qualifications.pearson.com/en/qualifications/"
                f"edexcel-international-advanced-levels/{slug}-2018.html"
            )
    return urls


def pearson_uk_candidate_urls(query: str, level: str | None) -> list[str]:
    """Return official Pearson UK course-page candidates for a subject query."""

    slugs = pearson_subject_slugs(query, level)
    if not slugs:
        return []
    normalized = normalize_level(level)
    urls: list[str] = []
    if normalized in {None, "gcse", "igcse"}:
        base = "https://qualifications.pearson.com/en/qualifications/edexcel-gcses"
        for slug in slugs:
            urls.extend(
                [
                    f"{base}/{slug}-2015.html",
                    f"{base}/{slug}-2016.html",
                    f"{base}/{slug}-2017.html",
                ]
            )
        if any(term in {"biology", "chemistry", "physics"} for term in subject_terms_from_query(query)):
            urls.append(f"{base}/sciences-2016.html")
    if normalized in {None, "as", "as-level", "a-level", "alevel", "as-a-level"}:
        base = "https://qualifications.pearson.com/en/qualifications/edexcel-a-levels"
        for slug in slugs:
            urls.extend(
                [
                    f"{base}/{slug}-2015.html",
                    f"{base}/{slug}-2017.html",
                    f"{base}/{slug}-a-2015.html",
                ]
            )
    return list(dict.fromkeys(urls))


def pearson_subject_slugs(query: str, level: str | None) -> list[str]:
    primary = subject_slug_from_query(query)
    slugs = [primary] if primary else []
    normalized = normalize_level(level)
    if normalized in {None, "gcse", "igcse", "international-gcse"}:
        text = query.lower()
        text = re.sub(r"\ba\s*level\b|\bas\s*a\s*level\b|\bas-a-level\b|\balevel\b", " ", text)
        text = re.sub(
            r"\b(pearson|edexcel|international|gcse|igcse|syllabus|specification|spec|pdf|guide|revision|handbook)\b",
            " ",
            text,
        )
        terms = re.findall(r"[a-z0-9]+", text)
        if len(terms) >= 2 and terms[-1] in {"a", "b"}:
            slugs.append("-".join(terms))
    return list(dict.fromkeys(slug for slug in slugs if slug))
